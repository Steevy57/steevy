const { purgeMessages } = require("@helpers/ModUtils");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "purgeuser",
  description: "Supprimer les messages d'un utilisateur",
  category: "MODERATION",
  userPermissions: ["ManageMessages"],
  botPermissions: ["ManageMessages", "ReadMessageHistory"],
  command: {
    enabled: true,
    usage: "<@user|ID> [amount]",
    aliases: ["purgeusers"],
    minArgsCount: 1,
  },

  async messageRun(message, args) {
    const target = await message.guild.resolveMember(args[0]);
    if (!target) return message.safeReply(`Aucun utilisateur trouvé pour ${args[0]}`);
    const amount = (args.length > 1 && args[1]) || 99;

    if (amount) {
      if (isNaN(amount)) return message.safeReply("Veuillez me donner un nombre");
      if (parseInt(amount) > 99) return message.safeReply("Le nombre ne doit pas dépasser 99");
    }

    const { channel } = message;
    const response = await purgeMessages(message.member, message.channel, "USER", amount, target);

    if (typeof response === "number") {
      return channel.safeSend(`${response} images supprimées`, 5);
    } else if (response === "BOT_PERM") {
      return message.safeReply("Je n'ai pas la permission `Lire l'historique des messages` et `Gérer les Messages`", 5);
    } else if (response === "MEMBER_PERM") {
      return message.safeReply("Tu n'as pas la permission `Lire l'historique des messages` et `Gérer les Messages`", 5);
    } else if (response === "NO_MESSAGES") {
      return channel.safeSend("Aucun message trouvé à supprimer", 5);
    } else {
      return message.safeReply(`Je ne peux pas supprimer de messages`);
    }
  },
};
