const { vMuteTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await vMuteTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.tag} est mute sur ce serveur`;
  }
  if (response === "MEMBER_PERM") {
    return `Tu n'as pas la permission de mute ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je n'ai pas la permission de mute ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est pas dans un salon vocale`;
  }
  if (response === "ALREADY_DEAFENED") {
    return `${target.user.tag} est déjà mute`;
  }
  return `Impossible de le mute ${target.user.tag}`;
};