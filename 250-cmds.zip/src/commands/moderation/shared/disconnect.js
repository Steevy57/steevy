const { disconnectTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await disconnectTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.tag} a été déconnecté`;
  }
  if (response === "MEMBER_PERM") {
    return `Tu ne peux pas deconnecter ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je ne peux pas déconnecterr ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} 'n'est pas dans un salon vocal'`;
  }
  return `Impossible de déconnecter ${target.user.tag}`;
};
