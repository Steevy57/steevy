const { moveTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason, channel) => {
  const response = await moveTarget(member, target, reason, channel);
  if (typeof response === "boolean") {
    return `${target.user.tag} a été move dans: ${channel}`;
  }
  if (response === "MEMBER_PERM") {
    return `Tu ne peux pas move ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je ne peux pas move ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est pas dans un salon vocale`;
  }
  if (response === "TARGET_PERM") {
    return `${target.user.tag} n'a pas la permission de rejoindre ${channel}`;
  }
  if (response === "ALREADY_IN_CHANNEL") {
    return `${target.user.tag} est déjà dans ${channel}`;
  }
  return `Impossible de move ${target.user.tag} dans ${channel}`;
};
