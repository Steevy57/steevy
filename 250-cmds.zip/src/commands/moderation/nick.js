const { canModerate } = require("@helpers/ModUtils");
const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "nick",
  description: "Rename un membre",
  category: "MODERATION",
  botPermissions: ["ManageNicknames"],
  userPermissions: ["ManageNicknames"],
  command: {
    enabled: true,
    minArgsCount: 2,
    subcommands: [
      {
        trigger: "set <@member> <name>",
        description: "Change le pseudo d'un membre",
      },
      {
        trigger: "reset <@member>",
        description: "Reinitialise le pseudo d'un membre",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "set",
        description: "Change le pseudo d'un membre",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "L'utilisateur à qui changer le pseudo",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
          {
            name: "name",
            description: "Le pseudo à mettre",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "reset",
        description: "Reinitialiser le pseudo d'un membre",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "Le membre à qui réinitialiser le pseudo",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args) {
    const sub = args[0].toLowerCase();

    if (sub === "set") {
      const target = await message.guild.resolveMember(args[1]);
      if (!target) return message.safeReply("Je ne peux pas trouver de membre");
      const name = args.slice(2).join(" ");
      if (!name) return message.safeReply("Donne moi un pseudo");

      const response = await nickname(message, target, name);
      return message.safeReply(response);
    }

    //
    else if (sub === "reset") {
      const target = await message.guild.resolveMember(args[1]);
      if (!target) return message.safeReply("Je ne trouve pas de membre pour");

      const response = await nickname(message, target);
      return message.safeReply(response);
    }
  },

  async interactionRun(interaction) {
    const name = interaction.options.getString("name");
    const target = await interaction.guild.members.fetch(interaction.options.getUser("user"));

    const response = await nickname(interaction, target, name);
    await interaction.followUp(response);
  },
};

async function nickname({ member, guild }, target, name) {
  if (!canModerate(member, target)) {
    return `Tu ne peux pas changer le pseudo de ${target.user.tag}`;
  }
  if (!canModerate(guild.members.me, target)) {
    return `Je ne peux pas changer le pseudo de ${target.user.tag}`;
  }

  try {
    await target.setNickname(name);
    return `Le pseudo de ${target.user.tag} a été ${name ? "changé" : "reinitialisé"}`;
  } catch (ex) {
    return `Impossible de ${name ? "changer" : "reinitaliser"} le pseudo de ${target.displayName}.`;
  }
}
