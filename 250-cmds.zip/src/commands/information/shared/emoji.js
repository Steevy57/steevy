const { parseEmoji, EmbedBuilder } = require("discord.js");
const { EMBED_COLORS } = require("@root/config");

module.exports = (emoji) => {
  let custom = parseEmoji(emoji);
  if (!custom.id) return "Cet emoji n'est pas sur le serveur";

  let url = `https://cdn.discordapp.com/emojis/${custom.id}.${custom.animated ? "gif?v=1" : "png"}`;

  const embed = new EmbedBuilder()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setAuthor({ name: "Informations de l'Emoji" })
    .setDescription(
      `**Id:** ${custom.id}\n` + `**Nom:** ${custom.name}\n` + `**Animé:** ${custom.animated ? "Oui" : "Non"}`
    )
    .setImage(url);

  return { embeds: [embed] };
};
