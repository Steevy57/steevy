const botinvite = require("../shared/botinvite");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "botinvite",
  description: "T'envoies l'invitation du bot",
  category: "INFORMATION",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
  },

  async messageRun(message, args) {
    const response = botinvite(message.client);
    try {
      await message.author.send(response);
      return message.safeReply("Check tes mp pour plus d'info! :envelope_with_arrow:");
    } catch (ex) {
      return message.safeReply("Je ne peux pas t'envoyer de mp! Sont-t'il ouvert?");
    }
  },
};
