const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "inviterank",
  description: "Configure des ranks d'invitations",
  category: "INVITE",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    usage: "<role-name> <invites>",
    minArgsCount: 2,
    subcommands: [
      {
        trigger: "add <role> <invites>",
        description: "Ajoute un auto role après avoir dépasser un nombre d'invitations",
      },
      {
        trigger: "remove role",
        description: "Retire un rank role",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "add",
        description: "Ajoute un nouveau rank d'invitation",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "role",
            description: "Le rôle à donner",
            type: ApplicationCommandOptionType.Role,
            required: true,
          },
          {
            name: "invites",
            description: "Le nombre d'invitations",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
      {
        name: "remove",
        description: "Retire un role",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "role",
            description: "Le rôle a retirer",
            type: ApplicationCommandOptionType.Role,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const sub = args[0].toLowerCase();

    if (sub === "add") {
      const query = args[1];
      const invites = args[2];

      if (isNaN(invites)) return message.safeReply(`\`${invites}\` Ceci n'est pas un nombre d'invitations?`);
      const role = message.guild.findMatchingRoles(query)[0];
      if (!role) return message.safeReply(`Aucun rôle trouvé pour \`${query}\``);

      const response = await addInviteRank(message, role, invites, data.settings);
      await message.safeReply(response);
    }

    //
    else if (sub === "remove") {
      const query = args[1];
      const role = message.guild.findMatchingRoles(query)[0];
      if (!role) return message.safeReply(`Aucun rôle trouvé pour \`${query}\``);
      const response = await removeInviteRank(message, role, data.settings);
      await message.safeReply(response);
    }

    //
    else {
      await message.safeReply("Commande incorrecte!");
    }
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    //
    if (sub === "add") {
      const role = interaction.options.getRole("role");
      const invites = interaction.options.getInteger("invites");

      const response = await addInviteRank(interaction, role, invites, data.settings);
      await interaction.followUp(response);
    }

    //
    else if (sub === "remove") {
      const role = interaction.options.getRole("role");
      const response = await removeInviteRank(interaction, role, data.settings);
      await interaction.followUp(response);
    }
  },
};

async function addInviteRank({ guild }, role, invites, settings) {
  if (!settings.invite.tracking) return `Le tracker d'invitations est désactivée dans ce serveur`;

  if (role.managed) {
    return "Tu ne peux pas donner un rôle de bot";
  }

  if (guild.roles.everyone.id === role.id) {
    return "Tu ne peux pas donner le rôle everyone.";
  }

  if (!role.editable) {
    return "Je n'ai pas les permissions de donner ce rôle?";
  }

  const exists = settings.invite.ranks.find((obj) => obj._id === role.id);

  let msg = "";
  if (exists) {
    exists.invites = invites;
    msg += "Des ranks ont été trouvés pour ce rôle, j'écrase les donnés\n";
  }

  settings.invite.ranks.push({ _id: role.id, invites });
  await settings.save();
  return `${msg}Configuration sauvegardée.`;
}

async function removeInviteRank({ guild }, role, settings) {
  if (!settings.invite.tracking) return `Le tracker d'invitation est désactivé sur ce serveur`;

  if (role.managed) {
    return "Tu ne peux pas donner un rôle de bot";
  }

  if (guild.roles.everyone.id === role.id) {
    return "Gu ne peux pas donner le rôle everyone.";
  }

  if (!role.editable) {
    return "Je n'ai pas les permissions de donner ce rôle?";
  }

  const exists = settings.invite.ranks.find((obj) => obj._id === role.id);
  if (!exists) return "Aucun rang d'invitation précédent n'est configuré pour ce rôle.";

  // delete element from array
  const i = settings.invite.ranks.findIndex((obj) => obj._id === role.id);
  if (i > -1) settings.invite.ranks.splice(i, 1);

  await settings.save();
  return "Configuration sauvegardée.";
}
