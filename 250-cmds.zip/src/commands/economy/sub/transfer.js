const { EmbedBuilder } = require("discord.js");
const { getUser } = require("@schemas/User");
const { ECONOMY, EMBED_COLORS } = require("@root/config");

module.exports = async (self, target, coins) => {
  if (isNaN(coins) || coins <= 0) return "Entre un nombre de coins valide";
  if (target.bot) return "Tu ne peux pas transferer à un bot!";
  if (target.id === self.id) return "Tu ne peux pas transferer à toi même!";

  const userDb = await getUser(self);

  if (userDb.bank < coins) {
    return `Balance à la banque insuffisante, tu as seulement ${userDb.bank}${ECONOMY.CURRENCY}coins dans ta banque.${
      userDb.coins > 0 && "\nTu dois d'abord déposer de l'argent"
    } `;
  }

  const targetDb = await getUser(target);

  userDb.bank -= coins;
  targetDb.bank += coins;

  await userDb.save();
  await targetDb.save();

  const embed = new EmbedBuilder()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setAuthor({ name: "Nouvelle Balance" })
    .setDescription(`Tu as transferrer ${coins}${ECONOMY.CURRENCY} a ${target.tag}`)
    .setTimestamp(Date.now());

  return { embeds: [embed] };
};
