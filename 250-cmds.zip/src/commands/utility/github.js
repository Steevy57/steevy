const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { MESSAGES } = require("@root/config.js");
const { getJson } = require("@helpers/HttpUtils");
const { stripIndent } = require("common-tags");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "github",
  description: "Affiche les statistiques github",
  cooldown: 10,
  category: "UTILITY",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    aliases: ["git"],
    usage: "<username>",
    minArgsCount: 1,
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "username",
        description: "Pseudo github",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },

  async messageRun(message, args) {
    const username = args.join(" ");
    const response = await getGithubUser(username, message.author);
    await message.safeReply(response);
  },

  async interactionRun(interaction) {
    const username = interaction.options.getString("username");
    const response = await getGithubUser(username, interaction.user);
    await interaction.followUp(response);
  },
};

const websiteProvided = (text) => (text.startsWith("http://") ? true : text.startsWith("https://"));

async function getGithubUser(target, author) {
  const response = await getJson(`https://api.github.com/users/${target}`);
  if (response.status === 404) return "```Aucun utillisateur trouver avec ce pseudo```";
  if (!response.success) return MESSAGES.API_ERROR;

  const json = response.data;
  const {
    login: username,
    name,
    id: githubId,
    avatar_url: avatarUrl,
    html_url: userPageLink,
    followers,
    following,
    bio,
    location,
    blog,
  } = json;

  let website = websiteProvided(blog) ? `[Clique Ici](${blog})` : "Non Donnée";
  if (website == null) website = "Non Donné";

  const embed = new EmbedBuilder()
    .setAuthor({
      name: `Utilisateur Github: ${username}`,
      url: userPageLink,
      iconURL: avatarUrl,
    })
    .addFields(
      {
        name: "Information de l'Utilisateur",
        value: stripIndent`
        **Nom Réel**: *${name || "Non Donné"}*
        **Localisation**: *${location}*
        **ID GitHub**: *${githubId}*
        **Site Web**: *${website}*\n`,
        inline: true,
      },
      {
        name: "Statistiques",
        value: `**Abonnées**: *${followers}*\n**Abonnements**: *${following}*`,
        inline: true,
      }
    )
    .setDescription(`**Bio**:\n${bio || "Non Donnée"}`)
    .setImage(avatarUrl)
    .setColor(0x6e5494)
    .setFooter({ text: `Demandé par ${author.tag}` });

  return { embeds: [embed] };
}
