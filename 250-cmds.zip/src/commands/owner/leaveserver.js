/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "leaveserver",
  description: "Quitte un serveur.",
  category: "OWNER",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    minArgsCount: 1,
    usage: "<serverId>",
  },
  slashCommand: {
    enabled: false,
  },

  async messageRun(message, args, data) {
    const input = args[0];
    const guild = message.client.guilds.cache.get(input);
    if (!guild) {
      return message.safeReply(
        `Aucun serveur trouver, donne moi un bot id.
        tu peux utiliser ${data.prefix}findserver/${data.prefix}listservers pour trouver l'id d"un serveur`
      );
    }

    const name = guild.name;
    try {
      await guild.leave();
      return message.safeReply(`\`${name}\` a été quitté`);
    } catch (err) {
      message.client.logger.error("GuildLeave", err);
      return message.safeReply(`Impossible de quitter le serveur \`${name}\``);
    }
  },
};
