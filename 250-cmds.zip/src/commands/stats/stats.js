const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { getMemberStats } = require("@schemas/MemberStats");
const { EMBED_COLORS } = require("@root/config");
const { stripIndents } = require("common-tags");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "stats",
  description: "Affiche les stats des membres sur le serveur",
  cooldown: 5,
  category: "STATS",
  command: {
    enabled: true,
    usage: "[@member|id]",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "user",
        description: "Choisis un membre",
        type: ApplicationCommandOptionType.User,
        required: false,
      },
    ],
  },

  async messageRun(message, args, data) {
    const target = (await message.guild.resolveMember(args[0])) || message.member;
    const response = await stats(target, data.settings);
    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const member = interaction.options.getMember("user") || interaction.member;
    const response = await stats(member, data.settings);
    await interaction.followUp(response);
  },
};

/**
 * @param {import('discord.js').GuildMember} member
 * @param {object} settings
 */
async function stats(member, settings) {
  if (!settings.stats.enabled) return "les stats sont désactivés sur ce serveur";
  const memberStats = await getMemberStats(member.guild.id, member.id);

  const embed = new EmbedBuilder()
    .setThumbnail(member.user.displayAvatarURL())
    .setColor(EMBED_COLORS.BOT_EMBED)
    .addFields(
      {
        name: "Tag du Membre",
        value: member.user.tag,
        inline: true,
      },
      {
        name: "ID",
        value: member.id,
        inline: true,
      },
      {
        name: "⌚ Membre Depuis",
        value: member.joinedAt.toLocaleString(),
        inline: false,
      },
      {
        name: "💬 Messages Envoyés",
        value: stripIndents`
      ❯ Messages Envoyés: ${memberStats.messages}
      ❯ Commandes Prefix: ${memberStats.commands.prefix}
      ❯ Commandes Slashs: ${memberStats.commands.slash}
      ❯ XP Gagné: ${memberStats.xp}
      ❯ Niveau Actuel: ${memberStats.level}
    `,
        inline: false,
      },
      {
        name: "🎙️ Stats Vocales",
        value: stripIndents`
      ❯ Connections Vocales: ${memberStats.voice.connections}
      ❯ Temps de Vocales: ${Math.floor(memberStats.voice.time / 60)} min
    `,
      }
    )
    .setFooter({ text: "Statistiques" })
    .setTimestamp();

  return { embeds: [embed] };
}
