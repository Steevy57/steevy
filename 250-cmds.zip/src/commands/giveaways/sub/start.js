const { ChannelType } = require("discord.js");

/**
 * @param {import('discord.js').GuildMember} member
 * @param {import('discord.js').GuildTextBasedChannel} giveawayChannel
 * @param {number} duration
 * @param {string} prize
 * @param {number} winners
 * @param {import('discord.js').User} [host]
 * @param {string[]} [allowedRoles]
 */
module.exports = async (member, giveawayChannel, duration, prize, winners, host, allowedRoles = []) => {
  try {
    if (!host) host = member.user;
    if (!member.permissions.has("ManageMessages")) {
      return "Tu dois avoir la permission `Gérer les Messages` pour modifier un giveaway.";
    }

    if (!giveawayChannel.type === ChannelType.GuildText) {
      return "Tu ne peux lancer des giveaways que dans un salons textuels.";
    }

    /**
     * @type {import("discord-giveaways").GiveawayStartOptions}
     */
    const options = {
      duration: duration,
      prize,
      winnerCount: winners,
      hostedBy: host,
      messages: {
        giveaway: "🎉 **GIVEAWAY** 🎉",
        giveawayEnded: "🎉 **GIVEAWAY FINI** 🎉",
        inviteToParticipate: "Réagi avec 🎉 pour participer",
        dropMessage: "Soit le premier à réagir sur 🎉 pour gagner!",
        hostedBy: `\nHosted by: ${host.tag}`,
      },
    };

    if (allowedRoles.length > 0) {
      options.exemptMembers = (member) => !member.roles.cache.find((role) => allowedRoles.includes(role.id));
    }

    await member.client.giveawaysManager.start(giveawayChannel, options);
    return `Giveaway lancé dans ${giveawayChannel}`;
  } catch (error) {
    member.client.logger.error("Giveaway Lancé", error);
    return `Une erreur c'est produite en voulant lancer le giveaway: ${error.message}`;
  }
};
