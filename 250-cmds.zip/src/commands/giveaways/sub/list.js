const { EMBED_COLORS } = require("@root/config");

/**
 * @param {import('discord.js').GuildMember} member
 */
module.exports = async (member) => {
  // Permissions
  if (!member.permissions.has("ManageMessages")) {
    return "Tu dois avoir la permission `Gérer les Messages` pour modifier un giveaway.";
  }

  // Search with all giveaways
  const giveaways = member.client.giveawaysManager.giveaways.filter(
    (g) => g.guildId === member.guild.id && g.ended === false
  );

  // No giveaways
  if (giveaways.length === 0) {
    return "Il n'y a aucun giveaway en cours dans ce serveur.";
  }

  const description = giveaways.map((g, i) => `${i + 1}. ${g.prize} - <#${g.channelId}>`).join("\n");

  try {
    return { embeds: [{ description, color: EMBED_COLORS.GIVEAWAYS }] };
  } catch (error) {
    member.client.logger.error("Liste des Giveaways", error);
    return `Une erreur c'est produite en voulant afficher la liste: ${error.message}`;
  }
};
