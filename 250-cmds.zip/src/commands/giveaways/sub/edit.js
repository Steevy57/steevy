/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 * @param {number} addDuration
 * @param {string} newPrize
 * @param {number} newWinnerCount
 */
module.exports = async (member, messageId, addDuration, newPrize, newWinnerCount) => {
  if (!messageId) return "Tu dois me donner l'id d'un message valide.";

  // Permissions
  if (!member.permissions.has("ManageMessages")) {
    return "Tu dois avoir la permission `Gérer les Messages` pour modifier un giveaway.";
  }

  // Search with messageId
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // If no giveaway was found
  if (!giveaway) return `Impossible de trouvé un giveaway pour cet id: ${messageId}`;

  try {
    await member.client.giveawaysManager.edit(messageId, {
      addTime: addDuration || 0,
      newPrize: newPrize || giveaway.prize,
      newWinnerCount: newWinnerCount || giveaway.winnerCount,
    });

    return `Giveaway mis à jour!`;
  } catch (error) {
    member.client.logger.error("Giveaway Modifié", error);
    return `Une erreur c'est produite en modifiant le giveaway: ${error.message}`;
  }
};
