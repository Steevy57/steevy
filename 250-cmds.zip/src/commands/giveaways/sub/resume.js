/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 */
module.exports = async (member, messageId) => {
  if (!messageId) return "Tu dois me donner un ID de message valide.";

  // Permissions
  if (!member.permissions.has("ManageMessages")) {
    return "Tu dois avoir la permission `Gérer les Messages` pour modifier un giveaway.";
  }

  // Search with messageId
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // If no giveaway was found
  if (!giveaway) return `Impossible de trouvé un giveaway pour cet id: ${messageId}`;

  // Check if the giveaway is unpaused
  if (!giveaway.pauseOptions.isPaused) return "Ce giveaway n'est pas en pause.";

  try {
    await giveaway.unpause();
    return "Giveaway repris!";
  } catch (error) {
    member.client.logger.error("Giveaway repris", error);
    return `Une erreur c'est produite lors du resume du giveaway: ${error.message}`;
  }
};
