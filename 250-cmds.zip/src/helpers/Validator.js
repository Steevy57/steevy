const CommandCategory = require("@structures/CommandCategory");
const permissions = require("./permissions");
const config = require("@root/config");
const { log, warn, error } = require("./Logger");
const { ApplicationCommandType } = require("discord.js");

module.exports = class Validator {
  static validateConfiguration() {
    log("Vérification des environnements et du fichier config");

    // Bot Token
    if (!process.env.BOT_TOKEN) {
      error("env: BOT_TOKEN ne peut pas être vide");
      process.exit(1);
    }

    // Validate Database Config
    if (!process.env.MONGO_CONNECTION) {
      error("env: MONGO_CONNECTION ne peut pas être vide");
      process.exit(1);
    }

    // Validate Dashboard Config
    if (config.DASHBOARD.enabled) {
      if (!process.env.BOT_SECRET) {
        error("env: BOT_SECRET ne peut pas être vide");
        process.exit(1);
      }
      if (!process.env.SESSION_PASSWORD) {
        error("env: SESSION_PASSWORD ne peut pas être vide");
        process.exit(1);
      }
      if (!config.DASHBOARD.baseURL || !config.DASHBOARD.failureURL || !config.DASHBOARD.port) {
        error("config.js: DASHBOARD details ne peut pas être vide");
        process.exit(1);
      }
    }

    // Cache Size
    if (isNaN(config.CACHE_SIZE.GUILDS) || isNaN(config.CACHE_SIZE.USERS) || isNaN(config.CACHE_SIZE.MEMBERS)) {
      error("config.js: CACHE_SIZE doit être un chiffre");
      process.exit(1);
    }

    // Music
    if (config.MUSIC.ENABLED) {
      if (!process.env.SPOTIFY_CLIENT_ID || !process.env.SPOTIFY_CLIENT_SECRET) {
        warn("env: SPOTIFY_CLIENT_ID ou SPOTIFY_CLIENT_SECRET est vide. Les musiques avec Spotify ne vont pas marcher");
      }
      if (config.MUSIC.LAVALINK_NODES.length == 0) {
        warn("config.js: Il doit y avoir un node pour Lavalink");
      }
      if (!["YT", "YTM", "SC"].includes(config.MUSIC.DEFAULT_SOURCE)) {
        warn("config.js: MUSIC.DEFAULT_SOURCE doit être YT, YTM ou SC");
      }
    }

    // Warnings
    if (config.OWNER_IDS.length === 0) warn("config.js: OWNER_IDS est vide");
    if (!config.SUPPORT_SERVER) warn("config.js: SUPPORT_SERVER n'est pas donné");
    if (!process.env.WEATHERSTACK_KEY) warn("env: WEATHERSTACK_KEY est vide. Les commandes météos ne vont pas fonctionner");
    if (!process.env.STRANGE_API_KEY) warn("env: STRANGE_API_KEY est vide. Les commandes images ne vont pas fonctionner");
  }

  /**
   * @param {import('@structures/Command')} cmd
   */
  static validateCommand(cmd) {
    if (typeof cmd !== "object") {
      throw new TypeError("Les commandes doivent etre des objects.");
    }
    if (typeof cmd.name !== "string" || cmd.name !== cmd.name.toLowerCase()) {
      throw new Error("Nom de commande doit être un string en minuscule.");
    }
    if (typeof cmd.description !== "string") {
      throw new TypeError("La description de la commande doit être un string.");
    }
    if (cmd.cooldown && typeof cmd.cooldown !== "number") {
      throw new TypeError("Cooldown de commande doit être un nombre");
    }
    if (cmd.category) {
      if (!Object.prototype.hasOwnProperty.call(CommandCategory, cmd.category)) {
        throw new Error(`${cmd.category} n'est pas une catégorie valide`);
      }
    }
    if (cmd.userPermissions) {
      if (!Array.isArray(cmd.userPermissions)) {
        throw new TypeError("userPermissions doit être une Array.");
      }
      for (const perm of cmd.userPermissions) {
        if (!permissions[perm]) throw new RangeError(`userPermission invalides: ${perm}`);
      }
    }
    if (cmd.botPermissions) {
      if (!Array.isArray(cmd.botPermissions)) {
        throw new TypeError("botPermissions doit être une Array.");
      }
      for (const perm of cmd.botPermissions) {
        if (!permissions[perm]) throw new RangeError(`botPermission invalides: ${perm}`);
      }
    }
    if (cmd.validations) {
      if (!Array.isArray(cmd.validations)) {
        throw new TypeError("Validations doit être une array.");
      }
      for (const validation of cmd.validations) {
        if (typeof validation !== "object") {
          throw new TypeError("Validationn doit être un object dans une Array.");
        }
        if (typeof validation.callback !== "function") {
          throw new TypeError("validation callback doit être une fonction.");
        }
        if (typeof validation.message !== "string") {
          throw new TypeError("validation message doit être un string.");
        }
      }
    }

    // Validate Command Details
    if (cmd.command) {
      if (typeof cmd.command !== "object") {
        throw new TypeError("Command.command doit être un object");
      }
      if (Object.prototype.hasOwnProperty.call(cmd.command, "enabled") && typeof cmd.command.enabled !== "boolean") {
        throw new TypeError("Command.command activé doit être un boolean");
      }
      if (
        cmd.command.aliases &&
        (!Array.isArray(cmd.command.aliases) ||
          cmd.command.aliases.some((ali) => typeof ali !== "string" || ali !== ali.toLowerCase()))
      ) {
        throw new TypeError("Command.command aliases doit être une array de string en minuscules.");
      }
      if (cmd.command.usage && typeof cmd.command.usage !== "string") {
        throw new TypeError("Command.command usage doit être un string");
      }
      if (cmd.command.minArgsCount && typeof cmd.command.minArgsCount !== "number") {
        throw new TypeError("Command.command minArgsCount doit être un nombre");
      }
      if (cmd.command.subcommands && !Array.isArray(cmd.command.subcommands)) {
        throw new TypeError("Command.command subcommands doit être une array");
      }
      if (cmd.command.subcommands) {
        for (const sub of cmd.command.subcommands) {
          if (typeof sub !== "object") {
            throw new TypeError("Command.command subcommands doit être une array d'objects");
          }
          if (typeof sub.trigger !== "string") {
            throw new TypeError("Command.command subcommand trigger doit être un string");
          }
          if (typeof sub.description !== "string") {
            throw new TypeError("Command.command subcommand description doit être un string");
          }
        }
      }
      if (cmd.command.enabled && typeof cmd.messageRun !== "function") {
        throw new TypeError("Missing 'messageRun' function");
      }
    }

    // Validate Slash Command Details
    if (cmd.slashCommand) {
      if (typeof cmd.slashCommand !== "object") {
        throw new TypeError("Command.slashCommand doit être un object");
      }
      if (
        Object.prototype.hasOwnProperty.call(cmd.slashCommand, "enabled") &&
        typeof cmd.slashCommand.enabled !== "boolean"
      ) {
        throw new TypeError("Command.slashCommand activé doit être une valeur boolean");
      }
      if (
        Object.prototype.hasOwnProperty.call(cmd.slashCommand, "ephemeral") &&
        typeof cmd.slashCommand.ephemeral !== "boolean"
      ) {
        throw new TypeError("Command.slashCommand ephemeral doit être une valeur boolean");
      }
      if (cmd.slashCommand.options && !Array.isArray(cmd.slashCommand.options)) {
        throw new TypeError("Command.slashCommand options doit être une array");
      }
      if (cmd.slashCommand.enabled && typeof cmd.interactionRun !== "function") {
        throw new TypeError("Missing 'interactionRun' function");
      }
    }
  }

  /**
   * @param {import('@structures/BaseContext')} context
   */
  static validateContext(context) {
    if (typeof context !== "object") {
      throw new TypeError("Context doit être un object");
    }
    if (typeof context.name !== "string" || context.name !== context.name.toLowerCase()) {
      throw new Error("Nom du context doit être un string en minuscule.");
    }
    if (typeof context.description !== "string") {
      throw new TypeError("La description du contexte doit être un string.");
    }
    if (context.type !== ApplicationCommandType.User && context.type !== ApplicationCommandType.Message) {
      throw new TypeError("Type de contexte doit être un User/Message.");
    }
    if (Object.prototype.hasOwnProperty.call(context, "enabled") && typeof context.enabled !== "boolean") {
      throw new TypeError("Context activé doit être une valeur boolean");
    }
    if (Object.prototype.hasOwnProperty.call(context, "ephemeral") && typeof context.ephemeral !== "boolean") {
      throw new TypeError("Context active doit être une valeur boolean");
    }
    if (
      Object.prototype.hasOwnProperty.call(context, "defaultPermission") &&
      typeof context.defaultPermission !== "boolean"
    ) {
      throw new TypeError("Context defaultPermission doit être une valeur boolean");
    }
    if (Object.prototype.hasOwnProperty.call(context, "cooldown") && typeof context.cooldown !== "number") {
      throw new TypeError("Context cooldown doit être un nombre");
    }
    if (context.userPermissions) {
      if (!Array.isArray(context.userPermissions)) {
        throw new TypeError("Context userPermissions doit être une Array de keys permission strings.");
      }
      for (const perm of context.userPermissions) {
        if (!permissions[perm]) throw new RangeError(`Commande invalide userPermission: ${perm}`);
      }
    }
  }
};
